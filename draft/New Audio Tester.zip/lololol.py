# audio_features.py
import librosa
import numpy as np

y, sr = librosa.load("output.wav", sr=16000, mono=True)

# 1) total duration (sec)
duration = librosa.get_duration(y=y, sr=sr)

# 2) silence ratio (simple: frames whose RMS < threshold)
rms = librosa.feature.rms(y=y, frame_length=1024, hop_length=512).flatten()
silence_threshold = 0.02 * rms.max()
silence_ratio = float((rms < silence_threshold).mean())

# 3) tempo (BPM) — useful for repetitive tasks (counting / pa-ta-ka)
tempo, _ = librosa.beat.beat_track(y=y, sr=sr)

print({
  "duration_sec": round(duration, 2),
  "silence_ratio": round(silence_ratio, 3),
  "tempo_bpm": round(float(tempo), 2)
})