# stt_whisper_noffmpeg.py
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly
import torch, whisper

WAV = r"output.wav"  # absolute path also works

# 1) read WAV
audio, sr = sf.read(WAV, always_2d=False)

# 2) to mono
if audio.ndim == 2:
    audio = audio.mean(axis=1)

# 3) resample to 16 kHz
target_sr = 16000
if sr != target_sr:
    g = np.gcd(sr, target_sr)
    up, down = target_sr // g, sr // g
    audio = resample_poly(audio, up, down)

# 4) float32 normalization
audio = audio.astype(np.float32)

# 5) load model
device = "cuda" if torch.cuda.is_available() else "cpu"
model = whisper.load_model("base", device=device)

# 6) mel spectrogram → decode (auto language or fixed)
mel = whisper.log_mel_spectrogram(whisper.pad_or_trim(audio)).to(device)
opts = whisper.DecodingOptions(language="en", task="transcribe")
result = whisper.decode(model, mel, opts)

print("text:", result.text)